<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <path d=""/>
</svg>
<?php /**PATH C:\xampp\htdocs\feenu(4)\resources\views/components/application-logo.blade.php ENDPATH**/ ?>