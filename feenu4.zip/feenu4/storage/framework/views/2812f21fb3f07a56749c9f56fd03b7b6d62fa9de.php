<?php $__env->startSection('main'); ?>
    <div class="nit-card">      
        <aside class="col-md-12">        
                 <div class="card">
                    <div class="card-body">
                        <h1>DMCA</h1>
                        <br>
                        <h4></h4>
            
                        <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <br>
                        <h6>Information</h6>
                        <br>
                        <div>At 46 Play, accessible from https://46play.com/, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by 46 Play and how we use it
                        </div>
                        <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>  <h6>Effective date: September 28,2018</h6>
                        <div>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.making
                            making it over
                        </div>
                        <div>If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
                        </div>
            
                
            
                    </div>
               </div>
             </aside>
 </div>        
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\feenu3023\resources\views/frontend/dmca.blade.php ENDPATH**/ ?>