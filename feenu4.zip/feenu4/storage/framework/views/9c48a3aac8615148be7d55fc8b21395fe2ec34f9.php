<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('main'); ?>
    <div class="container">
     <div class="nit-more-menu">
         <ul>
             <li><a href="<?php echo e(url('/most-played')); ?>"> most played</a></li>
             <li><a href="<?php echo e(url('/most-recommend')); ?>">most recommended </a></li>
             <li><a href="<?php echo e(url('/new-game')); ?>">NEW</a></li>
         </ul>
     </div>
     <div class="nit-content">
        <ul>
             <li><div class="nit-ads"><a href="#"><img src="<?php echo e(url('frontend/images/more/ads.png')); ?>" alt=""></a></div></li>
             <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
             <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li ><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i5.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i6.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i7.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i8.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
             <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li ><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i5.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i6.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i7.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i8.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="<?php echo e(url('/game')); ?>"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
             <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li ><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i5.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i6.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i7.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i8.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
             <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i1.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li ><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li class="newGame"><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i5.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i6.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i7.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i8.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i4.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i3.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
                <li><a href="<?php echo e(url('/game')); ?>"><img src="<?php echo e(url('frontend/images/more/i2.png')); ?>" alt=""><figcaption>ROAD</figcaption></a></li>
           </ul>
        </div>
     <div class="nit-loader">
         <div class="spinner-border"></div>
     </div>
     </div>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.Layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\feenu4\resources\views/user/dashboard.blade.php ENDPATH**/ ?>