@include('frontend.Layouts.header')
@yield('main')
@include('frontend.Layouts.footer')